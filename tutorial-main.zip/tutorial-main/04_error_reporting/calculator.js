export function add(a, b) {
  return x + y;
}

export function multiply(a, b) {
  return a + b;
}

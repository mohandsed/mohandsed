import {add} from './calculator'

it('adds numbers', () => {
  expect(add(1, 2)).toBe(3);
});
